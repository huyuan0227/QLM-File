package com.QLM.QLMFile.service;

import com.QLM.QLMFile.Vo.Details;
import com.QLM.QLMFile.mapper.DetailsMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class DetailsService extends ServiceImpl<DetailsMapper, Details> {

    @Autowired
    private DetailsMapper detailsMapper;

//    public IPage searchDetailsWithDepByPage(int page , int limit , Map n){
//        Page g = new Page(page,limit);
//        return detailsMapper.searchDetailsWithDepByPage(g,n);
//    }
    public IPage findbydetailsid (int page , int limit ,  Map m){
        Page p = new Page(page, limit);
        IPage result = detailsMapper.searchdetailsid(p ,m);
        return result;
    }

}
