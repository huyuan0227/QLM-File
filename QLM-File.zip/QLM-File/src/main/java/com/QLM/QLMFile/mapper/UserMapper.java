package com.QLM.QLMFile.mapper;


import com.QLM.QLMFile.Vo.Admin;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.apache.ibatis.annotations.Param;

import java.util.Map;

public interface UserMapper extends BaseMapper<Admin> {
     IPage searchUserWithDepByPage(Page p , @Param("m")Map m);

}
