package com.QLM.QLMFile.Vo;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;

import java.util.Date;

@TableName("Details")
public class Details implements java.io.Serializable {

    @TableField("detailsid")
    private Integer detailsid;

    private String dename;

    private String sop;

    private String advance;

    private String money;

    private String customer;

    private String business;

    private String technology;

    private Date kaitime;

    private Date jietime;

    public Integer getDetailsid() {
        return detailsid;
    }

    public void setDetailsid(Integer detailsid) {
        this.detailsid = detailsid;
    }

    public String getDename() {
        return dename;
    }

    public void setDename(String dename) {
        this.dename = dename;
    }

    public String getSop() {
        return sop;
    }

    public void setSop(String sop) {
        this.sop = sop;
    }

    public String getAdvance() {
        return advance;
    }

    public void setAdvance(String advance) {
        this.advance = advance;
    }

    public String getMoney() {
        return money;
    }

    public void setMoney(String money) {
        this.money = money;
    }

    public String getCustomer() {
        return customer;
    }

    public void setCustomer(String customer) {
        this.customer = customer;
    }

    public String getBusiness() {
        return business;
    }

    public void setBusiness(String business) {
        this.business = business;
    }

    public String getTechnology() {
        return technology;
    }

    public void setTechnology(String technology) {
        this.technology = technology;
    }

    public Date getKaitime() {
        return kaitime;
    }

    public void setKaitime(Date kaitime) {
        this.kaitime = kaitime;
    }

    public Date getJietime() {
        return jietime;
    }

    public void setJietime(Date jietime) {
        this.jietime = jietime;
    }
}
