package com.QLM.QLMFile.action;

import com.QLM.QLMFile.Vo.Details;
import com.QLM.QLMFile.Vo.ResponseBean;
import com.QLM.QLMFile.Vo.Admin;
import com.QLM.QLMFile.service.DetailsService;
import com.QLM.QLMFile.service.UserService;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
@CrossOrigin("*")
@RequestMapping("/api")
public class UserAction {

    @Autowired
    private UserService userService;
    @Autowired
    private DetailsService detailsService;

    @RequestMapping("/searchEmp")
    public ResponseBean changeUserSex(@RequestParam Map m)
    {
        System.out.println(m);
        //得到数据
        List<Admin> listuser = userService.findbyid(m);
        Integer oldSex = listuser.get(0).getSex();
        if (oldSex==null)
            oldSex = 0;
            listuser.get(0).setSex(1-listuser.get(0).getSex());
        boolean f = userService.updateById(listuser.get(0));
        int code = f ? 200 : 500;
        return new ResponseBean(code,0,listuser.get(0));
    }

    @RequestMapping("/searchDetails")
    public ResponseBean changeDetailsSex(@RequestParam(defaultValue = "1") int page ,@RequestParam(defaultValue = "10") int limit ,  @RequestParam Map n)
    {
        System.out.println(n);
        //得到数据
        IPage result = detailsService.findbydetailsid(page , limit , n);
//        Integer olddetailsid = listDetails.get(0).getDetailsid();
//        if (olddetailsid==null)
//            olddetailsid = 0;
//            listDetails.get(0).setDetailsid(1-listDetails.get(0).getDetailsid());
//            boolean s = detailsService.updateById(listDetails.get(0));
//            int code = s ? 200 : 500;
//            return new ResponseBean(code,0,listDetails.get(0));
        return new ResponseBean(0, result.getTotal(), result.getRecords());
    }
}
