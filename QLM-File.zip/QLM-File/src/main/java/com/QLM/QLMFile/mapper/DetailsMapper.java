package com.QLM.QLMFile.mapper;

import com.QLM.QLMFile.Vo.Details;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.apache.ibatis.annotations.Param;

import java.util.Map;

public interface DetailsMapper extends BaseMapper<Details> {
//    IPage searchDetailsWithDepByPage(Page g , @Param("n")Map n);
    IPage searchdetailsid(Page p , @Param("m") Map m);
}
