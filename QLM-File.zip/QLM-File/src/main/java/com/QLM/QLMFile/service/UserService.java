package com.QLM.QLMFile.service;

import com.QLM.QLMFile.Vo.Admin;
import com.QLM.QLMFile.mapper.UserMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class UserService extends ServiceImpl<UserMapper , Admin> {

    @Autowired
    private UserMapper userMapper;

    public IPage searchUserWithDepByPage(int page , int limit , Map m)
    {
        Page p = new Page(page , limit);
        return userMapper.searchUserWithDepByPage(p,m);
    }
    public List findbyid (Map m){
        List list = userMapper.selectList(null);
        return  list;

    }

}
